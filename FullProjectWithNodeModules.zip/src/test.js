let a = {a:10,b:20};
console.log(Object.keys(a).map(v=> a[v] *10));